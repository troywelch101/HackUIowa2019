﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;


namespace HackUIowa
{
    public class Dict
    {
        public string word {get;}
    }

    public class APIHelper : ApiController
    {    
        static HttpClient client = new HttpClient();

        public static async Task RunAsync()
        {
            client.BaseAddress = new Uri("http://localhost:44300");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }
        public static async Task<string> GetDictionaryAsync(string path)
        {
            client.BaseAddress = new Uri("http://localhost:44300");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            string keyword = null;
            HttpResponseMessage response = await client.GetAsync(path);

            string fuck = "";

            if (true || response.IsSuccessStatusCode)
            {
                keyword = await response.Content.ReadAsAsync<string>();
            }
            return keyword;
        } 
        
        public static string Dict (string path)
        {
            string rtnVal = "";
            string[] rtnValArr;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://random-word-api.herokuapp.com");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                //GET Method  
                var response = client.GetAsync("/word?key=VBQ9BG9P&number=1").Result;

                if (true)//response.IsSuccessStatusCode)
                {
                    rtnVal = response.Content.ReadAsAsync<Object>().Result.ToString();

                    char delim = '"';

                    rtnValArr = rtnVal.Split(delim);
                }
            }

            return rtnValArr[1].ToString();
        }
    }
}