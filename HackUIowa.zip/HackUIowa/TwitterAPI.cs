﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TweetSharp;
using System.Data;

namespace HackUIowa
{
    public class TwitterAPI : ApiController
    {
        //https://api.twitter.com/1.1/search/tweets.json?q=hello
        //%23 #
        //%22 "
        //sort Popular, Mixed, Recent
        public static int GetTweetCount(string word, TwitterSearchResultType sort)
        {
            string consumerKey = "WBPOHuyPqVihdZpLOS9kMdWlF"; //(API key)
            string consumerKeySecret = "2wHdWRnMzxOX6RaXGvXOxT6gwUJIsGgcQlWeFS3oxTIeA8fOo0"; //(API secret key)
            string accessToken = "2194243692-sIs9hZyu62kVHvDtZxykUCFFTk15eS418JFxtRg"; //(Access token)
            string accessTokenSecret = "zXpfTJjWlpUVPk263FTEQB31pxWgu3P6c0IgZQoDcne5O"; //(access token secret)

            TwitterService twitterService = new TwitterService(consumerKey, consumerKeySecret, accessToken, accessTokenSecret);
            twitterService.AuthenticateWith(accessToken, accessTokenSecret);

            int tweetCount = 0;
            //limited to 100
            var tweetsSearch = twitterService.Search(new SearchOptions { /*Q = word,*/ Lang = "en", Geocode = new TwitterGeoLocationSearch(41.661240, 91.5302, 400, TwitterGeoLocationSearch.RadiusType.Mi), Resulttype = sort, Count = 100 });

            List<TwitterStatus> resultList = new List<TwitterStatus>(tweetsSearch.Statuses);
            foreach (var tweet in tweetsSearch.Statuses)
            {
                try
                {
                    //tweet.User.ScreenName;  
                    //tweet.User.Name;   
                    //tweet.Text; // Tweet text  
                    //tweet.RetweetCount; //No of retweet on twitter  
                    //tweet.User.FavouritesCount; //No of Fav mark on twitter  
                    //tweet.User.ProfileImageUrl; //Profile Image of Tweet  
                    //tweet.CreatedDate; //For Tweet posted time  
                    //"https://twitter.com/intent/retweet?tweet_id=" + tweet.Id;  //For Retweet  
                    //"https://twitter.com/intent/tweet?in_reply_to=" + tweet.Id; //For Reply  
                    //"https://twitter.com/intent/favorite?tweet_id=" + tweet.Id; //For Favorite  

                    //Above are the things we can also get using TweetSharp.  

                    if (tweet.Text.Contains(word))
                    {
                        tweetCount++;
                    }

                }
                catch { }
            }
            return tweetCount;
        }

        //returns tweets sorted by Retweets or Favorites
        public static DataTable GetTweets(string word, string searchCriteria, TwitterSearchResultType sort)
        {
            string consumerKey = "WBPOHuyPqVihdZpLOS9kMdWlF"; //(API key)
            string consumerKeySecret = "2wHdWRnMzxOX6RaXGvXOxT6gwUJIsGgcQlWeFS3oxTIeA8fOo0"; //(API secret key)
            string accessToken = "2194243692-sIs9hZyu62kVHvDtZxykUCFFTk15eS418JFxtRg"; //(Access token)
            string accessTokenSecret = "zXpfTJjWlpUVPk263FTEQB31pxWgu3P6c0IgZQoDcne5O"; //(access token secret)
            
            DataTable tweetDT = new DataTable();
            tweetDT.Columns.Add("Content", typeof(string));
            tweetDT.Columns.Add("Criteria", typeof(int));

            TwitterService twitterService = new TwitterService(consumerKey, consumerKeySecret, accessToken, accessTokenSecret);
            twitterService.AuthenticateWith(accessToken, accessTokenSecret);

            //limited to 100
            var tweetsSearch = twitterService.Search(new SearchOptions { Q = word, Lang = "en", /*Geocode = new TwitterGeoLocationSearch(41.661240, 91.5302, 500, TwitterGeoLocationSearch.RadiusType.Mi),*/ Resulttype = sort, Count = 100 });

            List<TwitterStatus> resultList = new List<TwitterStatus>(tweetsSearch.Statuses);

            if(searchCriteria == "Retweets")
            {
                foreach (var tweet in tweetsSearch.Statuses)
                {
                    try
                    {
                        tweetDT.Rows.Add(tweet.Text, tweet.RetweetCount);
                    }
                    catch { }
                }

            } else
            {//favorites
                foreach (var tweet in tweetsSearch.Statuses)
                {
                    try
                    {
                        tweetDT.Rows.Add(tweet.Text, tweet.FavoriteCount);
                    }
                    catch { }
                }

            }

            tweetDT.DefaultView.Sort = "Criteria Desc";
            tweetDT = tweetDT.DefaultView.ToTable();

            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    if(tweetDT.Rows[i][0].ToString() == tweetDT.Rows[j][0].ToString())
                    {
                        tweetDT.Rows[j].Delete();
                    }
                }
            }

            tweetDT.AcceptChanges();

            return tweetDT;

        }

    }
}