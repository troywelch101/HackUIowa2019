﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace HackUIowa
{
    public partial class Game : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ViewState["currentTeam"] = "1";
                currentTeamLabel.Text = "1";
                answerDiv.Visible = false;

                teamOneNameLabel.Text = (string)Session["teamOne"] + ":";
                teamTwoNameLabel.Text = (string)Session["teamTwo"] + ":";

                //string word = APIHelper.Dict("https://random-word-api.herokuapp.com/word?key=VBQ9BG9P&number=1");

                Random rand = new Random();

                string word = wordArr[rand.Next(0, wordArr.Length)];

                int questionType = rand.Next(1, 3);

                if(questionType == 1)
                {
                    processQuestion(word);

                } else if(questionType == 2)
                {//Retweets
                    questionParagraph.InnerText = "Of the following which was retweeted the most?";

                    DataTable tweetsDT = TwitterAPI.GetTweets(word, "Retweets", TweetSharp.TwitterSearchResultType.Mixed);

                    answerParagraph.InnerText = string.Format("The answer was: {0}. with {1} Retweets", tweetsDT.Rows[0][0].ToString(), tweetsDT.Rows[0][1].ToString());

                    processQuestion(tweetsDT);
                } else
                {//Favorites
                    questionParagraph.InnerText = "Of the following which was favorited the most?";

                    DataTable tweetsDT = TwitterAPI.GetTweets(word, "Favorites", TweetSharp.TwitterSearchResultType.Mixed);

                    answerParagraph.InnerText = string.Format("The answer was: {0}. with {1} Favorites", tweetsDT.Rows[0][0].ToString(), tweetsDT.Rows[0][1].ToString());

                    processQuestion(tweetsDT);
                }
            }

            correctnessParagraph.InnerText = "You were wrong!";
        }

        private void processQuestion(string word)
        {
            countAnswerRow.Visible = true;
            mostPopularAnswerRow.Visible = false;
            tweetRow.Visible = false;
            questionParagraph.InnerText = string.Format("Out of 100 tweets how many contain: {0}", word);

            int answer = TwitterAPI.GetTweetCount(word, TweetSharp.TwitterSearchResultType.Popular);
            ViewState["answer"] = answer.ToString();
            answerParagraph.InnerText = "The answer was " + answer;

            answerGenerator(answer, out int fakeOne, out int fakeTwo, out int fakeThree);

            Random rand = new Random();
            int answerLocation = rand.Next(1, 4);
            switch (answerLocation)
            {
                case 1:
                    answerOne.InnerText = answer.ToString();
                    answerTwo.InnerText = fakeOne.ToString();
                    answerThree.InnerText = fakeTwo.ToString();
                    answerFour.InnerText = fakeThree.ToString();
                    break;
                case 2:
                    answerTwo.InnerText = answer.ToString();
                    answerOne.InnerText = fakeOne.ToString();
                    answerThree.InnerText = fakeTwo.ToString();
                    answerFour.InnerText = fakeThree.ToString();
                    break;
                case 3:
                    answerThree.InnerText = answer.ToString();
                    answerTwo.InnerText = fakeOne.ToString();
                    answerOne.InnerText = fakeTwo.ToString();
                    answerFour.InnerText = fakeThree.ToString();
                    break;
                case 4:
                    answerFour.InnerText = answer.ToString();
                    answerTwo.InnerText = fakeOne.ToString();
                    answerThree.InnerText = fakeTwo.ToString();
                    answerOne.InnerText = fakeThree.ToString();
                    break;
            }
        }

        private void processQuestion(DataTable tweetsDT)
        {
            countAnswerRow.Visible = false;
            mostPopularAnswerRow.Visible = true;
            tweetRow.Visible = true;

            Random rand = new Random();
            int answerLocation = rand.Next(1, 4);

            switch (answerLocation)
            {
                case 1:
                    answerOne.InnerText = tweetsDT.Rows[0][0].ToString();
                    answerTwo.InnerText = tweetsDT.Rows[1][0].ToString();
                    answerThree.InnerText = tweetsDT.Rows[2][0].ToString();
                    answerFour.InnerText = tweetsDT.Rows[3][0].ToString();
                    ViewState["answer"] = "A";
                    break;
                case 2:
                    answerTwo.InnerText = tweetsDT.Rows[0][0].ToString();
                    answerOne.InnerText = tweetsDT.Rows[1][0].ToString();
                    answerThree.InnerText = tweetsDT.Rows[2][0].ToString();
                    answerFour.InnerText = tweetsDT.Rows[3][0].ToString();
                    ViewState["answer"] = "B";
                    break;
                case 3:
                    answerThree.InnerText = tweetsDT.Rows[0][0].ToString();
                    answerTwo.InnerText = tweetsDT.Rows[1][0].ToString();
                    answerOne.InnerText = tweetsDT.Rows[2][0].ToString();
                    answerFour.InnerText = tweetsDT.Rows[3][0].ToString();
                    ViewState["answer"] = "C";
                    break;
                case 4:
                    answerFour.InnerText = tweetsDT.Rows[0][0].ToString();
                    answerTwo.InnerText = tweetsDT.Rows[1][0].ToString();
                    answerThree.InnerText = tweetsDT.Rows[2][0].ToString();
                    answerOne.InnerText = tweetsDT.Rows[3][0].ToString();
                    ViewState["answer"] = "D";
                    break;
            }
        }

        private void answerGenerator(int answer, out int fakeAnswerOne, out int fakeAnswerTwo, out int fakeAnswerThree) {
            Random rand = new Random();
            int min = answer-rand.Next(1, 25);

            if(min < 0)
            {
                min = 0;
            }

            int max = answer+rand.Next(1, 25);
        
            if(max > 100)
            {
                max = 100;
            }

            do
            {
                fakeAnswerOne = rand.Next(min, max);
            } while (fakeAnswerOne == answer);

            do
            {
                fakeAnswerTwo = rand.Next(min, max);
            } while (fakeAnswerTwo == answer || fakeAnswerTwo == fakeAnswerOne);

            do
            {
                fakeAnswerThree = rand.Next(min, max);
            } while (fakeAnswerThree == fakeAnswerOne || fakeAnswerThree == fakeAnswerTwo || fakeAnswerThree == answer);
        }
        
        private int IsAnswer(string choice)
        {
            int score = 0;
            string answer = (string)ViewState["answer"];

            if (choice == answer)
            {
                score = 2;
            }

            return score;
        }

        private int scoreCount(int choice)
        {
            int score = 0;
            int answer = int.Parse((string)ViewState["answer"]);

            if (answer - 1 <= choice && answer + 1 >= choice)
            {
                score = 4;
            } else if(answer - 4 <= choice && answer + 4 >= choice)
            {
                score = 2;
            } else if (answer - 7 <= choice && answer + 7 >= choice)
            {
                score = 1;
            }

            return score;
        }

        private void ScoreIncrement(string team, int score) {
            if(score != 0)
            {
                correctnessParagraph.InnerText = string.Format("You Scored {0} points!",score);
            }

            if(team == "1")
            {
                teamOneScoreLabel.Text = (int.Parse(teamOneScoreLabel.Text) + score).ToString();
            } else
            {
                teamTwoScoreLabel.Text = (int.Parse(teamTwoScoreLabel.Text) + score).ToString();
            }
        }

        private void SwitchTeam()
        {
            if((string)ViewState["currentTeam"] == "1")
            {
                ViewState["currentTeam"] = "2";
                currentTeamLabel.Text = teamTwoNameLabel.Text;
            } else
            {
                ViewState["currentTeam"] = "1";
                currentTeamLabel.Text = teamOneNameLabel.Text;
            }
        }

        protected void answerOneButton_Click(object sender, EventArgs e)
        {
            ScoreIncrement((string)ViewState["currentTeam"], IsAnswer(answerFour.InnerText));

            answerDiv.Visible = true;
        }

        protected void answerTwoButton_Click(object sender, EventArgs e)
        {
            ScoreIncrement((string)ViewState["currentTeam"], IsAnswer(answerFour.InnerText));

            answerDiv.Visible = true;
        }

        protected void answerThreeButton_Click(object sender, EventArgs e)
        {
            ScoreIncrement((string)ViewState["currentTeam"], IsAnswer(answerFour.InnerText));

            answerDiv.Visible = true;
        }

        protected void answerFourButton_Click(object sender, EventArgs e)
        {
            ScoreIncrement((string)ViewState["currentTeam"], IsAnswer(answerFour.InnerText));

            answerDiv.Visible = true;
        }

        protected void submitCountGuessButton_Click(object sender, EventArgs e)
        {
            if(int.TryParse(countGuessTextbox.Text, out int guess))
            {
                ScoreIncrement((string)ViewState["currentTeam"], scoreCount(guess));

                answerDiv.Visible = true;
            }
        }

        protected void searchWordButton_Click(object sender, EventArgs e)
        {
            processQuestion(searchWordTextbox.Text);
        }

        protected void closeAnswerDiv_Click(object sender, EventArgs e)
        {
            //Changes the team label
            SwitchTeam();

            answerDiv.Visible = false;

            //string word = APIHelper.Dict("https://random-word-api.herokuapp.com/word?key=VBQ9BG9P&number=1");
            
            //choose random question type and word to search
            Random rand = new Random();

            string word = wordArr[rand.Next(0, wordArr.Length)];

            int questionType = rand.Next(1, 3);

            questionType = 2;

            if (questionType == 1)
            {
                processQuestion(word);
            }
            else if (questionType == 2)
            {//Retweets
                questionParagraph.InnerText = "Of the following which was retweeted the most?";

                DataTable tweetsDT = TwitterAPI.GetTweets(word, "Retweets", TweetSharp.TwitterSearchResultType.Mixed);

                answerParagraph.InnerText = string.Format("The answer was: {0}. with {1} Retweets", tweetsDT.Rows[0][0].ToString(), tweetsDT.Rows[0][1].ToString());

                processQuestion(tweetsDT);
            }
            else
            {//Favorites
                questionParagraph.InnerText = "Of the following which was favorited the most?";

                DataTable tweetsDT = TwitterAPI.GetTweets(word, "Favorites", TweetSharp.TwitterSearchResultType.Mixed);

                answerParagraph.InnerText = string.Format("The answer was: {0}. with {1} Favorites", tweetsDT.Rows[0][0].ToString(), tweetsDT.Rows[0][1].ToString());

                processQuestion(tweetsDT);
            }
        }

        protected string[] wordArr = new string[]
        {
            "#", "@", "!", "$", "the", "nice", "talk", " a ", "going", "never", "happy", "good", "job", "work"
        };

        protected string[] goodArr = new string[]
        {
            "#", "@", "!", "fuck"
        };

        
    }
}